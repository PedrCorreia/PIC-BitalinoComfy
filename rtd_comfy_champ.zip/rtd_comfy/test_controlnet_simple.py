#!/usr/bin/env python3
"""
Simple test for ControlNet node functionality
"""
import sys
import os
import torch
import numpy as np
from PIL import Image

# Add ComfyUI to path
sys.path.append('/home/lugo/ComfyUI')
sys.path.append('/home/lugo/ComfyUI/custom_nodes/rtd_comfy')

def create_test_depth_map(size=(512, 512)):
    """Create a test depth map with clear sphere pattern"""
    width, height = size
    depth_map = np.zeros((height, width), dtype=np.float32)
    
    # Create a very clear sphere pattern
    center_x, center_y = width // 2, height // 2
    radius = min(width, height) // 4
    
    for y in range(height):
        for x in range(width):
            dx = x - center_x
            dy = y - center_y
            distance = np.sqrt(dx*dx + dy*dy)
            
            if distance <= radius:
                # Strong sphere depth gradient
                normalized_dist = distance / radius
                sphere_depth = 1.0 - normalized_dist  # Linear gradient for clear effect
                depth_map[y, x] = sphere_depth
    
    return depth_map

def test_controlnet_node():
    """Test just the ControlNet node functionality"""
    
    try:
        # Import the ControlNet node
        from comfy.controlnet_node import ControlNetNode
        
        print("[Test] Testing ControlNet node...")
        
        # Create test depth map
        depth_array = create_test_depth_map((512, 512))
        print(f"[Test] Created depth map. Range: [{depth_array.min():.3f}, {depth_array.max():.3f}]")
        
        # Save depth map for visual inspection
        depth_image = Image.fromarray((depth_array * 255).astype(np.uint8), mode='L')
        depth_image.save('/home/lugo/ComfyUI/custom_nodes/rtd_comfy/test_depth_visual.png')
        print("[Test] Saved depth map as test_depth_visual.png")
        
        # Convert to ComfyUI tensor format [batch, height, width, channels]
        depth_tensor = torch.from_numpy(depth_array).unsqueeze(0).unsqueeze(-1)
        print(f"[Test] Depth tensor shape: {depth_tensor.shape}")
        
        # Test ControlNet node
        controlnet_node = ControlNetNode()
        
        # Test different scales
        for scale in [1.0, 2.0, 3.0]:
            print(f"\n[Test] Testing ControlNet with scale: {scale}")
            
            # Run the ControlNet node
            result = controlnet_node.run(
                controlnet_type="depth",
                control_image=depth_tensor,
                scale=scale,
                enable_download=True
            )
            
            controlnet_params = result[0]  # First element of tuple
            
            print(f"[Test] ControlNet parameters:")
            print(f"  - Type: {type(controlnet_params)}")
            print(f"  - Keys: {list(controlnet_params.keys()) if isinstance(controlnet_params, dict) else 'Not a dict'}")
            
            if isinstance(controlnet_params, dict):
                print(f"  - Model path: {controlnet_params.get('model', 'Not found')}")
                print(f"  - Scale: {controlnet_params.get('scale', 'Not found')}")
                
                control_image = controlnet_params.get('control_image')
                if control_image is not None:
                    print(f"  - Control image shape: {control_image.shape}")
                    print(f"  - Control image range: [{control_image.min():.3f}, {control_image.max():.3f}]")
                    
                    # Save processed control image
                    if isinstance(control_image, torch.Tensor):
                        img_array = control_image.squeeze().detach().cpu().numpy()
                        if img_array.max() <= 1.0:
                            img_array = (img_array * 255).astype(np.uint8)
                        processed_image = Image.fromarray(img_array, mode='L')
                        processed_image.save(f'/home/lugo/ComfyUI/custom_nodes/rtd_comfy/test_processed_depth_scale_{scale}.png')
                        print(f"  - Saved processed control image: test_processed_depth_scale_{scale}.png")
        
        print("\n[Test] ControlNet node test completed successfully!")
        print("Files created:")
        print("- test_depth_visual.png (original depth map)")
        print("- test_processed_depth_scale_*.png (processed control images)")
        
        # Check if model was downloaded
        model_dir = '/home/lugo/ComfyUI/models/controlnet'
        if os.path.exists(model_dir):
            models = os.listdir(model_dir)
            print(f"\n[Test] ControlNet models in {model_dir}:")
            for model in models:
                print(f"  - {model}")
        else:
            print(f"\n[Test] ControlNet model directory not found: {model_dir}")
        
    except Exception as e:
        print(f"[Test] Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_controlnet_node()
