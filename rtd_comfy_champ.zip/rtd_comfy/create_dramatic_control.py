#!/usr/bin/env python3
"""
Test script to verify ControlNet influence by creating a more dramatic control image
and comparing results with/without ControlNet
"""

import sys
import os
import numpy as np
import torch
from PIL import Image
import matplotlib.pyplot as plt

def create_dramatic_sphere_depth(size=512):
    """Create a very dramatic sphere depth map that should be obvious in the output"""
    y, x = np.ogrid[:size, :size]
    center_y, center_x = size // 2, size // 2
    
    # Create a large sphere that fills most of the image
    radius = size * 0.4  # Larger sphere
    distance_from_center = np.sqrt((x - center_x)**2 + (y - center_y)**2)
    
    # Create depth map with dramatic contrast
    depth_map = np.zeros((size, size))
    
    # Inside the sphere: create a very obvious dome shape
    mask = distance_from_center <= radius
    normalized_distance = distance_from_center[mask] / radius
    
    # Use a steep curve to create dramatic depth difference
    depth_values = 1.0 - normalized_distance**0.5  # Steep falloff
    depth_map[mask] = depth_values
    
    # Make the contrast even more dramatic
    depth_map = depth_map ** 2  # Square for more contrast
    
    # Ensure full range [0, 1]
    depth_map = (depth_map - depth_map.min()) / (depth_map.max() - depth_map.min())
    
    return depth_map

def create_checkerboard_depth(size=512):
    """Create a checkerboard pattern that should be very obvious"""
    depth_map = np.zeros((size, size))
    block_size = size // 8  # 8x8 grid
    
    for i in range(0, size, block_size):
        for j in range(0, size, block_size):
            # Checkerboard pattern
            if ((i // block_size) + (j // block_size)) % 2 == 0:
                depth_map[i:i+block_size, j:j+block_size] = 1.0
            else:
                depth_map[i:i+block_size, j:j+block_size] = 0.0
    
    return depth_map

def save_control_images():
    """Create and save dramatic control images for testing"""
    
    # Create dramatic sphere
    sphere_depth = create_dramatic_sphere_depth()
    sphere_img = Image.fromarray((sphere_depth * 255).astype(np.uint8))
    sphere_img.save('/home/lugo/ComfyUI/custom_nodes/rtd_comfy/dramatic_sphere_depth.png')
    print("✅ Saved dramatic_sphere_depth.png")
    
    # Create checkerboard
    checker_depth = create_checkerboard_depth()
    checker_img = Image.fromarray((checker_depth * 255).astype(np.uint8))
    checker_img.save('/home/lugo/ComfyUI/custom_nodes/rtd_comfy/checkerboard_depth.png')
    print("✅ Saved checkerboard_depth.png")
    
    # Create visualization
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    
    axes[0].imshow(sphere_depth, cmap='gray')
    axes[0].set_title('Dramatic Sphere Depth')
    axes[0].axis('off')
    
    axes[1].imshow(checker_depth, cmap='gray')
    axes[1].set_title('Checkerboard Depth')
    axes[1].axis('off')
    
    plt.tight_layout()
    plt.savefig('/home/lugo/ComfyUI/custom_nodes/rtd_comfy/control_images_preview.png', dpi=150, bbox_inches='tight')
    print("✅ Saved control_images_preview.png")
    
    print(f"Sphere depth range: [{sphere_depth.min():.3f}, {sphere_depth.max():.3f}]")
    print(f"Checkerboard depth range: [{checker_depth.min():.3f}, {checker_depth.max():.3f}]")

def analyze_existing_sphere():
    """Analyze the existing sphere_depth.png to see if it's dramatic enough"""
    try:
        existing_img = Image.open('/home/lugo/ComfyUI/custom_nodes/rtd_comfy/sphere_depth.png').convert('L')
        existing_array = np.array(existing_img) / 255.0
        
        print(f"Existing sphere depth range: [{existing_array.min():.3f}, {existing_array.max():.3f}]")
        print(f"Existing sphere depth std: {existing_array.std():.3f}")
        
        # Check if it has good contrast
        if existing_array.std() < 0.2:
            print("❌ Existing sphere has low contrast - creating new dramatic version")
            return False
        else:
            print("✅ Existing sphere has good contrast")
            return True
            
    except FileNotFoundError:
        print("❌ sphere_depth.png not found - creating new dramatic version")
        return False

if __name__ == "__main__":
    print("Creating dramatic control images for ControlNet testing...")
    
    # Check existing sphere
    has_good_contrast = analyze_existing_sphere()
    
    # Create new dramatic images
    save_control_images()
    
    print("\n=== TESTING RECOMMENDATIONS ===")
    print("1. Try the dramatic_sphere_depth.png with scale=2.0")
    print("2. Try the checkerboard_depth.png with scale=1.5")
    print("3. Compare output with ControlNet OFF vs ON")
    print("4. The checkerboard should create obvious geometric patterns")
    print("5. The dramatic sphere should create clear depth/lighting effects")
