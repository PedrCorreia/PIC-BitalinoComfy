#!/usr/bin/env python3
"""
Visual test for ControlNet integration - creates comparison images
"""
import sys
import os
import torch
import numpy as np
from PIL import Image, ImageDraw
import matplotlib.pyplot as plt

# Add the project to path
sys.path.append('/home/lugo/ComfyUI/custom_nodes/rtd_comfy')

def create_strong_depth_map(size=(512, 512)):
    """Create a very strong, high-contrast depth map with clear sphere"""
    width, height = size
    
    # Create numpy array
    depth_map = np.zeros((height, width), dtype=np.float32)
    
    # Create a sphere with very strong depth gradient
    center_x, center_y = width // 2, height // 2
    radius = min(width, height) // 4
    
    for y in range(height):
        for x in range(width):
            # Distance from center
            dx = x - center_x
            dy = y - center_y
            distance = np.sqrt(dx*dx + dy*dy)
            
            if distance <= radius:
                # Create a very pronounced sphere depth
                # Use cosine for smooth sphere shape
                normalized_dist = distance / radius
                # Make it very pronounced (0.0 to 1.0 range)
                sphere_depth = np.cos(normalized_dist * np.pi / 2)
                depth_map[y, x] = sphere_depth
            else:
                # Background depth
                depth_map[y, x] = 0.0
    
    return depth_map

def test_controlnet_visual():
    """Test ControlNet with visual comparison"""
    
    try:
        # Import our modules
        from comfy.controlnet_node import ControlNetNode
        from comfy.diffusion_engine import LRDiffusionEngineAcid
        
        print("[Test] Starting ControlNet visual test...")
        
        # Create a very strong depth map
        depth_array = create_strong_depth_map((512, 512))
        
        # Save the depth map for inspection
        depth_image = Image.fromarray((depth_array * 255).astype(np.uint8), mode='L')
        depth_image.save('/home/lugo/ComfyUI/custom_nodes/rtd_comfy/test_depth_map.png')
        print(f"[Test] Saved depth map. Range: [{depth_array.min():.3f}, {depth_array.max():.3f}]")
        
        # Convert to tensor format that ComfyUI expects
        # ComfyUI expects [batch, height, width, channels] format
        depth_tensor = torch.from_numpy(depth_array).unsqueeze(0).unsqueeze(-1)  # [1, 512, 512, 1]
        print(f"[Test] Depth tensor shape: {depth_tensor.shape}")
        
        # Test ControlNet node
        controlnet_node = ControlNetNode()
        
        # Test with higher scale for more pronounced effect
        test_scales = [1.0, 2.0, 3.0]
        
        for scale in test_scales:
            print(f"\n[Test] Testing ControlNet with scale: {scale}")
            
            # Create ControlNet parameters
            controlnet_params = controlnet_node.run(
                controlnet_type="depth",
                control_image=depth_tensor,
                scale=scale,
                enable_download=True
            )[0]  # Get first element from tuple
            
            print(f"[Test] ControlNet params created:")
            print(f"  - Model: {controlnet_params['model']}")
            print(f"  - Scale: {controlnet_params['scale']}")
            print(f"  - Image shape: {controlnet_params['control_image'].shape}")
            print(f"  - Image range: [{controlnet_params['control_image'].min():.3f}, {controlnet_params['control_image'].max():.3f}]")
            
            # Test the diffusion engine integration
            try:
                diffusion_engine = LRDiffusionEngineAcid()
                
                # Test parameters for image generation
                test_prompt = "a beautiful landscape with mountains and valleys, highly detailed"
                
                print(f"[Test] Testing diffusion engine with ControlNet scale {scale}...")
                
                # This should now properly handle ControlNet parameters
                result = diffusion_engine.generate(
                    prompt=test_prompt,
                    negative_prompt="",
                    steps=20,
                    cfg_scale=7.5,
                    width=512,
                    height=512,
                    seed=12345,
                    controlnet_params=controlnet_params
                )
                
                print(f"[Test] Generated image with ControlNet scale {scale}:")
                print(f"  - Result type: {type(result)}")
                if hasattr(result, 'shape'):
                    print(f"  - Shape: {result.shape}")
                
                # Save the result if it's an image
                if isinstance(result, torch.Tensor):
                    # Convert tensor to PIL Image for saving
                    if result.dim() == 4:  # [batch, channels, height, width]
                        result = result.squeeze(0)  # Remove batch dimension
                    if result.dim() == 3:  # [channels, height, width]
                        if result.shape[0] == 3:  # RGB
                            result = result.permute(1, 2, 0)  # [height, width, channels]
                    
                    # Convert to numpy and ensure proper range
                    result_np = result.detach().cpu().numpy()
                    if result_np.max() <= 1.0:
                        result_np = (result_np * 255).astype(np.uint8)
                    else:
                        result_np = np.clip(result_np, 0, 255).astype(np.uint8)
                    
                    # Save the image
                    if len(result_np.shape) == 3:
                        result_image = Image.fromarray(result_np, mode='RGB')
                    else:
                        result_image = Image.fromarray(result_np, mode='L')
                    
                    output_path = f'/home/lugo/ComfyUI/custom_nodes/rtd_comfy/test_controlnet_output_scale_{scale}.png'
                    result_image.save(output_path)
                    print(f"[Test] Saved result image: {output_path}")
                
            except Exception as e:
                print(f"[Test] Error in diffusion engine test: {e}")
                import traceback
                traceback.print_exc()
        
        print("\n[Test] ControlNet visual test completed!")
        print("Check the generated images to see if ControlNet depth effect is visible:")
        print("- test_depth_map.png (the control image)")
        print("- test_controlnet_output_scale_*.png (generated images)")
        
    except Exception as e:
        print(f"[Test] Error in visual test: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_controlnet_visual()
