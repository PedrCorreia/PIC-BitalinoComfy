#!/usr/bin/env python3
"""
Test script to verify ControlNet is having visual impact
Creates a dramatic control image and tests with different scales
"""

import sys
import os
import numpy as np
import torch
from PIL import Image

# Add ComfyUI to path
sys.path.append('/home/lugo/ComfyUI')
sys.path.append('/home/lugo/ComfyUI/custom_nodes/rtd_comfy')

def create_dramatic_control_image(size=512):
    """Create a very dramatic control image that should be clearly visible"""
    print("Creating dramatic control image...")
    
    # Create a high-contrast pattern
    img = np.zeros((size, size, 3), dtype=np.uint8)
    
    # Create strong diagonal stripes
    for i in range(size):
        for j in range(size):
            # Create diagonal pattern
            if (i + j) % 60 < 30:
                img[i, j] = [255, 255, 255]  # White
            else:
                img[i, j] = [0, 0, 0]        # Black
    
    # Add a central circle for depth
    center = size // 2
    radius = size // 4
    y, x = np.ogrid[:size, :size]
    mask = (x - center)**2 + (y - center)**2 <= radius**2
    
    # Make center area very bright (close to camera)
    img[mask] = [255, 255, 255]
    
    # Create depth gradient around circle
    for i in range(size):
        for j in range(size):
            dist_from_center = np.sqrt((i - center)**2 + (j - center)**2)
            if dist_from_center > radius:
                # Further from center = darker (further away)
                depth_val = max(0, 255 - int((dist_from_center - radius) * 2))
                img[i, j] = [depth_val, depth_val, depth_val]
    
    # Save the control image for inspection
    control_pil = Image.fromarray(img)
    control_pil.save('/home/lugo/ComfyUI/custom_nodes/rtd_comfy/dramatic_control_image.png')
    print("✅ Saved dramatic control image: dramatic_control_image.png")
    
    return img

def test_controlnet_workflow():
    """Test ControlNet in a ComfyUI workflow"""
    print("\n=== TESTING CONTROLNET WORKFLOW ===")
    
    try:
        # Import ComfyUI components
        import comfy.model_management as model_management
        from nodes import CheckpointLoaderSimple, CLIPTextEncode
        
        # Import our custom nodes
        from comfy.controlnet_node import ControlNetNode
        from comfy.diffusion_engine import LRDiffusionEngineLoader, LRDiffusionEngineAcid
        
        print("✅ All imports successful")
        
        # Create dramatic control image
        control_img = create_dramatic_control_image()
        
        # Convert to tensor format (ComfyUI expects batch dimension)
        control_tensor = torch.from_numpy(control_img).float() / 255.0
        control_tensor = control_tensor.unsqueeze(0)  # Add batch dimension
        
        print(f"✅ Control tensor shape: {control_tensor.shape}")
        print(f"✅ Control tensor range: [{control_tensor.min():.3f}, {control_tensor.max():.3f}]")
        
        # Test ControlNet node
        controlnet_node = ControlNetNode()
        controlnet_result = controlnet_node.run(
            controlnet_type="depth",
            control_image=control_tensor,
            scale=2.0,  # High scale for maximum impact
            enable_download=True
        )
        
        print(f"✅ ControlNet node returned: {type(controlnet_result)}")
        controlnet_params = controlnet_result[0]
        print(f"✅ ControlNet params keys: {list(controlnet_params.keys())}")
        print(f"✅ ControlNet scale: {controlnet_params['scale']}")
        
        # Test diffusion engine
        loader = LRDiffusionEngineLoader()
        engine_result = loader.load(
            height_diffusion=512,
            width_diffusion=512,
            do_compile=False,
            img2img=True
        )
        engine = engine_result[0]
        print(f"✅ DiffusionEngine created: {type(engine)}")
        
        # Create simple embeddings
        dummy_embeds = (
            torch.zeros(1, 77, 2048),  # prompt_embeds
            torch.zeros(1, 77, 2048),  # negative_prompt_embeds  
            torch.zeros(1, 1280),      # pooled_prompt_embeds
            torch.zeros(1, 1280),      # negative_pooled_prompt_embeds
        )
        
        # Set up basic parameters
        engine.set_embeddings(dummy_embeds)
        engine.set_num_inference_steps(1)  # Fast test
        
        # Create a simple input image
        test_image = np.ones((512, 512, 3), dtype=np.uint8) * 128  # Gray image
        engine.set_input_image(test_image)
        
        print("\n=== TESTING WITH CONTROLNET ===")
        
        # Test with ControlNet
        acid = LRDiffusionEngineAcid()
        
        try:
            result_with_controlnet = acid.generate(
                diffusion_engine=engine,
                embeds=dummy_embeds,
                input_image=test_image,
                num_inference_steps=1,
                controlnet_params=controlnet_params
            )
            
            print(f"✅ Generation with ControlNet successful!")
            print(f"✅ Result type: {type(result_with_controlnet)}")
            
            # Save result if it's an image
            if hasattr(result_with_controlnet, 'save'):
                result_with_controlnet.save('/home/lugo/ComfyUI/custom_nodes/rtd_comfy/result_with_controlnet.png')
                print("✅ Saved result: result_with_controlnet.png")
            
        except Exception as e:
            print(f"❌ Generation with ControlNet failed: {e}")
            import traceback
            traceback.print_exc()
            return False
        
        print("\n=== TESTING WITHOUT CONTROLNET ===")
        
        # Test without ControlNet for comparison
        try:
            result_without_controlnet = acid.generate(
                diffusion_engine=engine,
                embeds=dummy_embeds,
                input_image=test_image,
                num_inference_steps=1,
                controlnet_params=None  # No ControlNet
            )
            
            print(f"✅ Generation without ControlNet successful!")
            
            # Save result if it's an image
            if hasattr(result_without_controlnet, 'save'):
                result_without_controlnet.save('/home/lugo/ComfyUI/custom_nodes/rtd_comfy/result_without_controlnet.png')
                print("✅ Saved result: result_without_controlnet.png")
                
        except Exception as e:
            print(f"❌ Generation without ControlNet failed: {e}")
            import traceback
            traceback.print_exc()
        
        print("\n✅ ControlNet visual impact test completed!")
        print("Check the saved images to compare the difference:")
        print("  - dramatic_control_image.png (the control image)")
        print("  - result_with_controlnet.png (with ControlNet)")
        print("  - result_without_controlnet.png (without ControlNet)")
        
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_controlnet_workflow()
    if success:
        print("\n🎉 ControlNet integration test PASSED!")
    else:
        print("\n❌ ControlNet integration test FAILED!")
