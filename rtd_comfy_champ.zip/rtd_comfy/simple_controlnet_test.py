#!/usr/bin/env python3
"""
Simple test to check basic ControlNet functionality and identify deprecation warnings.
"""

import sys
import os
import warnings
import numpy as np
from PIL import Image

# Capture warnings
warnings.filterwarnings('default')

# Add paths
sys.path.append('/home/lugo/ComfyUI/custom_nodes/rtd_comfy')
sys.path.append('/home/lugo/ComfyUI/custom_nodes/PIC-BitalinoComfy')

print("=== Simple ControlNet Test ===")

try:
    from comfy.diffusion_engine import DiffusionEngineComfy
    print("✅ Successfully imported DiffusionEngineComfy")
except Exception as e:
    print(f"❌ Failed to import DiffusionEngineComfy: {e}")
    sys.exit(1)

try:
    from comfy.tools import DepthMapNode
    print("✅ Successfully imported DepthMapNode")
except Exception as e:
    print(f"❌ Failed to import DepthMapNode: {e}")
    sys.exit(1)

# Check if ControlNet model exists
controlnet_model_path = "/home/lugo/ComfyUI/models/controlnet/diffusers_controlnet-depth-sdxl-1.0-small"
if os.path.exists(controlnet_model_path):
    print(f"✅ ControlNet model found at: {controlnet_model_path}")
else:
    print(f"❌ ControlNet model NOT found at: {controlnet_model_path}")
    print("Available models:")
    models_dir = "/home/lugo/ComfyUI/models/controlnet"
    if os.path.exists(models_dir):
        for item in os.listdir(models_dir):
            print(f"  - {item}")
    else:
        print("  Models directory doesn't exist")
    sys.exit(1)

# Create a simple test image
print("\n=== Creating test image ===")
test_image = Image.new('RGB', (512, 512), (128, 128, 128))
print("✅ Created test image")

# Generate depth map
print("\n=== Generating depth map ===")
try:
    depth_node = DepthMapNode()
    depth_map = depth_node.process_image(test_image)
    print(f"✅ Generated depth map, shape: {depth_map.shape if hasattr(depth_map, 'shape') else type(depth_map)}")
except Exception as e:
    print(f"❌ Failed to generate depth map: {e}")
    sys.exit(1)

# Initialize diffusion engine
print("\n=== Initializing DiffusionEngine ===")
try:
    diffusion_engine = DiffusionEngineComfy(
        height_diffusion_desired=512,
        width_diffusion_desired=512,
        use_image2image=True,
        device='cuda',
        hf_model='stabilityai/sdxl-turbo'
    )
    print("✅ DiffusionEngine initialized")
except Exception as e:
    print(f"❌ Failed to initialize DiffusionEngine: {e}")
    sys.exit(1)

# Set embeddings
print("\n=== Setting embeddings ===")
try:
    prompt = "A simple test image"
    diffusion_engine.set_embeddings(prompt)
    print("✅ Embeddings set")
except Exception as e:
    print(f"❌ Failed to set embeddings: {e}")
    sys.exit(1)

# Set image init
print("\n=== Setting image init ===")
try:
    diffusion_engine.set_image_init(test_image)
    diffusion_engine.set_num_inference_steps(1)  # Very fast for testing
    print("✅ Image init set")
except Exception as e:
    print(f"❌ Failed to set image init: {e}")
    sys.exit(1)

# Test ControlNet setting
print("\n=== Testing ControlNet setting ===")
try:
    print("Setting ControlNet...")
    diffusion_engine.set_controlnet(
        model=controlnet_model_path,
        control_image=depth_map,
        scale=0.5
    )
    print("✅ ControlNet set successfully")
    
    # Check if attributes are set correctly
    print(f"  - controlnet: {type(getattr(diffusion_engine, 'controlnet', None))}")
    print(f"  - controlnet_image: {type(getattr(diffusion_engine, 'controlnet_image', None))}")
    print(f"  - controlnet_scale: {getattr(diffusion_engine, 'controlnet_scale', None)}")
    
except Exception as e:
    print(f"❌ Failed to set ControlNet: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test kwargs building
print("\n=== Testing kwargs building ===")
try:
    kwargs = diffusion_engine.build_kwargs()
    print("✅ build_kwargs() successful")
    print("Built kwargs keys:", list(kwargs.keys()))
    
    if 'controlnet' in kwargs:
        print(f"  - controlnet: {type(kwargs['controlnet'])}")
    if 'control_image' in kwargs:
        print(f"  - control_image: {type(kwargs['control_image'])}")
    if 'controlnet_conditioning_scale' in kwargs:
        print(f"  - controlnet_conditioning_scale: {kwargs['controlnet_conditioning_scale']}")
        
except Exception as e:
    print(f"❌ Failed to build kwargs: {e}")
    import traceback
    traceback.print_exc()

print("\n=== Test Complete ===")
print("If no errors appeared above, the ControlNet integration should be working correctly.")
print("Any deprecation warnings during actual generation would be visible during image generation.")
