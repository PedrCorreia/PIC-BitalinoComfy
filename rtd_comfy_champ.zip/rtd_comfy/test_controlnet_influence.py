#!/usr/bin/env python3
"""
Test script to check if ControlNet is actually influencing the generated images.
This will generate two images:
1. Without ControlNet (baseline)
2. With ControlNet and depth conditioning
Then compare them to see if there's a visual difference.
"""

import sys
import os
import numpy as np
from PIL import Image
import torch

# Add the project paths
sys.path.append('/home/lugo/ComfyUI/custom_nodes/rtd_comfy')
sys.path.append('/home/lugo/ComfyUI/custom_nodes/PIC-BitalinoComfy')

from comfy.diffusion_engine import DiffusionEngineComfy
from comfy.tools import DepthMapNode

def test_controlnet_influence():
    """Test if ControlNet actually influences the generated images."""
    
    print("=== Testing ControlNet Influence ===")
    
    # Create a test input image
    test_image = Image.new('RGB', (512, 512), (128, 128, 128))
    # Add some geometric shapes for depth detection
    import cv2
    img_array = np.array(test_image)
    
    # Draw some shapes to create depth variation
    cv2.rectangle(img_array, (100, 100), (200, 200), (255, 255, 255), -1)  # White square (foreground)
    cv2.circle(img_array, (300, 300), 50, (64, 64, 64), -1)  # Dark circle (background)
    cv2.rectangle(img_array, (250, 50), (450, 150), (192, 192, 192), -1)  # Gray rectangle (middle)
    
    test_image = Image.fromarray(img_array)
    test_image.save("test_input_image.png")
    print("Created test input image: test_input_image.png")
    
    # Generate depth map
    depth_node = DepthMapNode()
    depth_map = depth_node.process_image(test_image)
    
    # Convert depth map to PIL Image for saving
    if isinstance(depth_map, torch.Tensor):
        depth_array = depth_map.squeeze().cpu().numpy()
        if depth_array.ndim == 3 and depth_array.shape[0] == 1:
            depth_array = depth_array[0]
    else:
        depth_array = depth_map
    
    # Normalize depth map for visualization
    depth_norm = (depth_array - depth_array.min()) / (depth_array.max() - depth_array.min() + 1e-8)
    depth_vis = (depth_norm * 255).astype(np.uint8)
    
    # Convert to RGB if grayscale
    if depth_vis.ndim == 2:
        depth_vis = np.stack([depth_vis, depth_vis, depth_vis], axis=-1)
    
    depth_image = Image.fromarray(depth_vis)
    depth_image.save("test_depth_map.png")
    print("Generated depth map: test_depth_map.png")
    
    # Initialize diffusion engine
    diffusion_engine = DiffusionEngineComfy(
        height_diffusion_desired=512,
        width_diffusion_desired=512,
        use_image2image=True,
        device='cuda',
        hf_model='stabilityai/sdxl-turbo'
    )
    
    # Set common parameters
    prompt = "A beautiful ancient temple with detailed stone architecture"
    diffusion_engine.set_embeddings(prompt)
    diffusion_engine.set_image_init(test_image)
    diffusion_engine.set_num_inference_steps(2)
    diffusion_engine.seed = 12345  # Fixed seed for comparison
    
    print("\n=== Generating WITHOUT ControlNet (Baseline) ===")
    
    # Generate without ControlNet
    torch.manual_seed(12345)
    image_without_controlnet = diffusion_engine.generate()
    image_without_controlnet.save("output_without_controlnet.png")
    print("Generated baseline image: output_without_controlnet.png")
    
    print("\n=== Generating WITH ControlNet ===")
    
    # Load and set ControlNet
    controlnet_model_path = "/home/lugo/ComfyUI/models/controlnet/diffusers_controlnet-depth-sdxl-1.0-small"
    
    if not os.path.exists(controlnet_model_path):
        print(f"ERROR: ControlNet model not found at {controlnet_model_path}")
        print("Please ensure the ControlNet model is downloaded first.")
        return
    
    # Set ControlNet with strong conditioning
    diffusion_engine.set_controlnet(
        model=controlnet_model_path,
        control_image=depth_map,  # Use the tensor directly
        scale=1.5  # Strong conditioning to see clear difference
    )
    
    # Generate with ControlNet
    torch.manual_seed(12345)  # Same seed for fair comparison
    image_with_controlnet = diffusion_engine.generate()
    image_with_controlnet.save("output_with_controlnet.png")
    print("Generated ControlNet image: output_with_controlnet.png")
    
    print("\n=== Analysis ===")
    
    # Convert images to numpy arrays for comparison
    img1 = np.array(image_without_controlnet)
    img2 = np.array(image_with_controlnet)
    
    # Calculate pixel-wise difference
    diff = np.abs(img1.astype(float) - img2.astype(float))
    avg_diff = np.mean(diff)
    max_diff = np.max(diff)
    
    print(f"Average pixel difference: {avg_diff:.2f}")
    print(f"Maximum pixel difference: {max_diff:.2f}")
    
    # Create difference visualization
    diff_vis = (diff / max_diff * 255).astype(np.uint8)
    diff_image = Image.fromarray(diff_vis)
    diff_image.save("difference_visualization.png")
    print("Difference visualization saved: difference_visualization.png")
    
    # Determine if ControlNet is working
    threshold = 10.0  # Minimum average difference to consider ControlNet as working
    
    if avg_diff > threshold:
        print(f"\n✅ SUCCESS: ControlNet IS influencing the output!")
        print(f"The images show significant differences (avg: {avg_diff:.2f} > {threshold})")
    else:
        print(f"\n❌ ISSUE: ControlNet may NOT be influencing the output!")
        print(f"The images are too similar (avg: {avg_diff:.2f} <= {threshold})")
        print("This suggests ControlNet conditioning might not be working properly.")
    
    print("\n=== Test Complete ===")
    print("Generated files:")
    print("- test_input_image.png (input)")
    print("- test_depth_map.png (depth conditioning)")
    print("- output_without_controlnet.png (baseline)")
    print("- output_with_controlnet.png (with ControlNet)")
    print("- difference_visualization.png (diff between outputs)")

if __name__ == "__main__":
    test_controlnet_influence()
