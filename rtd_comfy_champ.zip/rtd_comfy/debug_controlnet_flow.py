#!/usr/bin/env python3
"""
Debug script to trace ControlNet parameter flow through the system
"""

import sys
import os
sys.path.append('/home/lugo/ComfyUI')
sys.path.append('/home/lugo/ComfyUI/custom_nodes/rtd_comfy')

try:
    from comfy.controlnet_node import ControlNetNode
    from comfy.diffusion_engine import LRDiffusionEngineAcid, LRDiffusionEngineLoader
    from sdxl_turbo.diffusion_engine import DiffusionEngine
    import torch
    import numpy as np
    from PIL import Image
    print("✅ All imports successful")
except Exception as e:
    print(f"❌ Import error: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

def create_test_image():
    """Create a simple test image"""
    print("Creating test image...")
    img_array = np.ones((512, 512, 3), dtype=np.uint8) * 128  # Gray image
    return img_array

def debug_controlnet_node():
    """Test the ControlNet node"""
    print("\n=== TESTING CONTROLNET NODE ===")
    
    node = ControlNetNode()
    test_image = create_test_image()
    
    try:
        result = node.process_controlnet(
            input_image=test_image,
            controlnet_type="depth",
            scale=0.5
        )
        print(f"✅ ControlNet node returned: {type(result)}")
        if isinstance(result, tuple) and len(result) > 0:
            controlnet_params = result[0]
            print(f"✅ ControlNet params type: {type(controlnet_params)}")
            if isinstance(controlnet_params, dict):
                print(f"✅ ControlNet params keys: {list(controlnet_params.keys())}")
                for key, value in controlnet_params.items():
                    print(f"  - {key}: {type(value)} - {str(value)[:100]}")
            return controlnet_params
        else:
            print(f"❌ Unexpected ControlNet node result format: {result}")
            return None
    except Exception as e:
        print(f"❌ ControlNet node error: {e}")
        import traceback
        traceback.print_exc()
        return None

def debug_diffusion_engine(controlnet_params):
    """Test the diffusion engine setup"""
    print("\n=== TESTING DIFFUSION ENGINE ===")
    
    try:
        # Create diffusion engine
        loader = LRDiffusionEngineLoader()
        engines = loader.load(
            height_diffusion=512,
            width_diffusion=512,
            do_compile=False,
            img2img=True
        )
        engine = engines[0]
        print(f"✅ DiffusionEngine created: {type(engine)}")
        
        # Test set_controlnet method
        if hasattr(engine, 'set_controlnet'):
            print("✅ DiffusionEngine has set_controlnet method")
            
            if controlnet_params:
                model = controlnet_params.get("model")
                control_image = controlnet_params.get("control_image")
                scale = controlnet_params.get("scale", 1.0)
                
                print(f"Calling set_controlnet with:")
                print(f"  - model: {type(model)} - {str(model)[:100]}")
                print(f"  - control_image: {type(control_image)}")
                print(f"  - scale: {scale}")
                
                try:
                    engine.set_controlnet(model, control_image, scale)
                    print("✅ set_controlnet called successfully")
                    
                    # Check attributes
                    print(f"Engine attributes after set_controlnet:")
                    print(f"  - controlnet: {type(getattr(engine, 'controlnet', None))}")
                    print(f"  - controlnet_image: {type(getattr(engine, 'controlnet_image', None))}")
                    print(f"  - controlnet_scale: {getattr(engine, 'controlnet_scale', None)}")
                    
                except Exception as e:
                    print(f"❌ set_controlnet failed: {e}")
                    import traceback
                    traceback.print_exc()
            else:
                print("❌ No controlnet_params to test with")
        else:
            print("❌ DiffusionEngine missing set_controlnet method")
            
        return engine
        
    except Exception as e:
        print(f"❌ DiffusionEngine creation failed: {e}")
        import traceback
        traceback.print_exc()
        return None

def debug_acid_wrapper(engine, controlnet_params):
    """Test the LRDiffusionEngineAcid wrapper"""
    print("\n=== TESTING ACID WRAPPER ===")
    
    if not engine:
        print("❌ No engine to test with")
        return
        
    try:
        # Create dummy embeddings (4-tuple format)
        dummy_embeds = (
            torch.zeros(1, 77, 2048),  # prompt_embeds
            torch.zeros(1, 77, 2048),  # negative_prompt_embeds  
            torch.zeros(1, 1280),      # pooled_prompt_embeds
            torch.zeros(1, 1280),      # negative_pooled_prompt_embeds
        )
        print("✅ Created dummy embeddings")
        
        # Test image
        test_image = create_test_image()
        
        # Create acid wrapper
        acid = LRDiffusionEngineAcid()
        print("✅ Created LRDiffusionEngineAcid")
        
        # Test parameter flow - we'll just check the parameter processing part
        print(f"Testing parameter flow with controlnet_params: {type(controlnet_params)}")
        
        # Manually call the ControlNet setup part
        if controlnet_params is not None:
            print("Processing ControlNet params in acid wrapper...")
            model = controlnet_params.get("model")
            control_image = controlnet_params.get("control_image")
            scale = controlnet_params.get("scale", 1.0)
            
            print(f"  - model: {type(model)}")
            print(f"  - control_image: {type(control_image)}")
            print(f"  - scale: {scale}")
            
            if hasattr(engine, "set_controlnet"):
                print("Calling engine.set_controlnet...")
                try:
                    engine.set_controlnet(model, control_image, scale)
                    print("✅ engine.set_controlnet succeeded")
                except Exception as e:
                    print(f"❌ engine.set_controlnet failed: {e}")
                    import traceback
                    traceback.print_exc()
            
            # Check engine attributes after setting
            print(f"Engine attributes after ControlNet setup:")
            print(f"  - controlnet: {getattr(engine, 'controlnet', 'NOT_SET')}")
            print(f"  - controlnet_image: {type(getattr(engine, 'controlnet_image', None))}")
            print(f"  - controlnet_scale: {getattr(engine, 'controlnet_scale', 'NOT_SET')}")
        
        return True
        
    except Exception as e:
        print(f"❌ Acid wrapper test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    print("Starting ControlNet parameter flow debug...")
    
    # 1. Test ControlNet node
    controlnet_params = debug_controlnet_node()
    
    # 2. Test DiffusionEngine
    engine = debug_diffusion_engine(controlnet_params)
    
    # 3. Test Acid wrapper
    debug_acid_wrapper(engine, controlnet_params)
    
    print("\n=== DEBUG COMPLETE ===")

if __name__ == "__main__":
    main()
